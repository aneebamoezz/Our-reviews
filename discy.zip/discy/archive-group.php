<?php get_header();
	include locate_template("theme-parts/loop-groups.php");
get_footer();?>